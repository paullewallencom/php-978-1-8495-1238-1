			<div id="main">
			
				<div id="rightside">
				</div>
				
				<div id="content">
					<h1>Connections of {connecting_name}</h1>
					<ul>
					<!-- START all -->
					<li>{plural_name} with {users_name}</p>
					<!-- END all -->
					</ul>
				</div>
			
			</div>