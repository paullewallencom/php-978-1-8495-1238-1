			<div id="main">
			
				<div id="rightside">
				</div>
				
				<div id="content"><h1>Recent updates</h1>
					<!-- START updates -->
					{update-{ID}}
					<!-- END updates -->
				</div>
			</div>