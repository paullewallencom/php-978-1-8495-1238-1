<p><strong>{poster_name}</strong>: {update}</p>
<!-- START comments-{ID} -->
<p>&nbsp;Comments:</p>
<p>&nbsp;{comment} by {commenter}</p>
<!-- END comments-{ID} -->