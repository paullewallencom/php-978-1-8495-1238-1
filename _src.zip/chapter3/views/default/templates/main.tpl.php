<div id="main">
			
				<div id="rightside">
				</div>
				
				<div id="content">
				<h1>Welcome to DINO SPACE!</h1>
				
				<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent porta cursus egestas. Donec ultricies rhoncus leo. Nulla feugiat, tellus eu consequat semper, nunc tortor dictum elit, et imperdiet metus ligula sit amet justo. Integer dictum, ante ac aliquet condimentum, erat dolor viverra nulla, sit amet auctor ligula libero in dui. Donec vulputate lorem ut diam dapibus posuere mollis nulla venenatis. Nulla ligula diam, convallis mollis dignissim non, tincidunt a enim. Morbi luctus molestie odio nec facilisis. Sed imperdiet adipiscing mauris, at vehicula sem consequat et. Nunc arcu lectus, sagittis quis ornare eu, sollicitudin eget ipsum. Aenean facilisis tortor quis libero dapibus accumsan. Sed egestas nibh felis, non porta quam. In ut diam mauris. Nunc vulputate velit tincidunt ipsum malesuada condimentum. Sed ac tellus auctor nunc fringilla auctor.
</p>			</div>
			
			</div>