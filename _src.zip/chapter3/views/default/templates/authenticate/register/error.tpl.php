<p>Sorry, there were a few errors with your registration attempt.  Please ammend them, and try again.</p>
<ul>
<!-- START errors -->
<li>{error_text}</li>
<!-- END errors -->
</ul>