<?php

$configs = array();
$configs['db_host_sn'] = 'localhost';
$configs['db_user_sn'] = 'root';
$configs['db_pass_sn'] = '';
$configs['db_name_sn'] = 'chapter11';


?>