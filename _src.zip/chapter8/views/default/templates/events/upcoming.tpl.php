			<div id="main">
			
				<div id="rightside">
				</div>
				
				<div id="content">
					<h1>Upcoming events in your network</h1>
					<ul>
					<!-- START events -->
					<li><a href="events/view/{ID}">{name}</a></li>
					<!-- END events -->
					</ul>
				</div>
			
			</div>