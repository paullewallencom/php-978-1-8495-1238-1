<p><strong>{poster_name}</strong>: posted an image "{update}"</p>
<img src="uploads/statusimages/{image}" alt="Image" />
<!-- START comments-{ID} -->
<p>&nbsp;Comments:</p>
<p>&nbsp;{comment} by {commenter}</p>
<!-- END comments-{ID} -->