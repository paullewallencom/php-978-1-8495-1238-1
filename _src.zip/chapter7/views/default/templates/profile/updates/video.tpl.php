<p><strong>{poster_name}</strong>: posted an video "{update}"</p>
<object width="200" height="164"><param name="movie" value="http://www.youtube.com/v/{video_id}&amp;hl=en_GB&amp;fs=1?rel=0&amp;border=1"></param><param name="allowFullScreen" value="true"></param><param name="allowscriptaccess" value="always"></param><embed src="http://www.youtube.com/v/{video_id}&amp;hl=en_GB&amp;fs=1?rel=0&amp;border=1" type="application/x-shockwave-flash" allowscriptaccess="always" allowfullscreen="true" width="200" height="164"></embed></object>
<!-- START comments-{ID} -->
<p>&nbsp;Comments:</p>
<p>&nbsp;{comment} by {commenter}</p>
<!-- END comments-{ID} -->
