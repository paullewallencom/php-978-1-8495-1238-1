<p><strong>{poster_name}</strong>: posted an link "{update}"</p>
<a href="{URL}">{description}</a>
<!-- START comments-{ID} -->
<p>&nbsp;Comments:</p>
<p>&nbsp;{comment} by {commenter}</p>
<!-- END comments-{ID} -->