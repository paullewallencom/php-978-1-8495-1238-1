-->
<p style="border: 1px solid #000; padding: 5px;">You are not connected to {profile_name}, so your message was not saved.</p>
<!--