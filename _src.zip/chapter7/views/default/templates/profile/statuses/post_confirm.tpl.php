-->
<p style="border: 1px solid #000; padding: 5px;">Your message has been posted on {profile_name}'s profile</p>
<!--