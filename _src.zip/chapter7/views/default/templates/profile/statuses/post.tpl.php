<p>Post a message on {profile_name}'s profile</p>
<form action="profile/statuses/{profile_user_id}" method="post">
<textarea id="status" name="status"></textarea>
<br />
<input type="submit" id="postmessage" name="postmessage" value="Update" />
</form>