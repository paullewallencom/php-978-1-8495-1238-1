<p>{statusposter_name} posted {statusupdate} on your profile</p>
<p class="postedtime">Posted {statusfriendly_time}</p>