<p>You posted on {statusprofile_name}'s profile: {statusupdate}</p>
<p class="postedtime">Posted {statusfriendly_time}</p>