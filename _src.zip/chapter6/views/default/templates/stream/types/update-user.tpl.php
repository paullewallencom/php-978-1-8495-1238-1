<p>{statusprofile_name} updated their status to {statusupdate}.</p>
<p class="postedtime">Posted {statusfriendly_time}</p>