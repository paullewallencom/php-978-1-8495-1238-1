<p>{statusposter_name} posted {statusupdate} on {statusprofile_name}'s profile</p>
<p class="postedtime">{statusfriendly_time}</p>