<p>You updated your status to {statusupdate}</p>
<p class="postedtime">Posted {statusfriendly_time}</p>