<div id="main">
			
				<div id="rightside">
				</div>
				
				<div id="content">
				<h1>Updates in your network</h1>
				
				<!-- START stream -->
					{stream-{status_id}}
					<!-- START comments-{status_id} -->
					<p>&nbsp;{comment} by {commenter}</p>
					<!-- END comments-{status_id} -->
					<!-- START likes-{status_id} -->
						<p>{iker} likes this</p>
						<!-- END likes-{status_id} -->
						
						<!-- START dislikes-{status_id} -->
						<p>{iker} dislikes this</p>
						<!-- END dislikes-{status_id} -->
						
						
				<!-- END stream -->
				
				
				</div>
			
			</div>