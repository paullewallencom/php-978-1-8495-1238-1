			<div id="main">
			
				<div id="rightside">
				
					<ul>
						<li><a href="groups/create">Create a new group</a></li>
						
					</ul>
				</div>
				
				<div id="content">
					<h1>My groups</h1>
					<!-- START my-groups -->
					<h2><a href="group/{ID}">{name}</a></h2>
					<p>{description}</p>
					<hr />
					<!-- END my-groups -->
					
				</div>
			
			</div>