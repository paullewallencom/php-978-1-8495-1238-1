			<div id="main">
			
				<div id="rightside">
					<ul>
						<li><a href="groups/create">Create new group</a></li>
					</ul>

				</div>
				
				<div id="content">
					<h1>No public groups</h1>
					<p>Sorry, there are currently no public groups.</p>
				</div>
			
			</div>